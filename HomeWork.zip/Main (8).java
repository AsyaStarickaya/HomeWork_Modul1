import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите длину стороны квадрата:");
    int a = scanner.nextInt();

    System.out.println("Периметр квадрата:");
    System.out.println(a * a);
  }
}