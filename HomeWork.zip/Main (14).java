import java.util.Scanner;

public class Main {
  private static final int PERCENT = 100;

  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);


    System.out.println("Введите количество проголосовавших за первого кандидата:");
    int firstCandidate = scanner.nextInt();

    System.out.println("Введите количество проголосовавших за второго кандидата:");
    int secondCandidate = scanner.nextInt();

    int totalAmountOfCandidates = secondCandidate + firstCandidate;

    System.out.println(
        "Первый кандидат набрал: " + firstCandidate * PERCENT / totalAmountOfCandidates + "%");
    System.out.println(
        "Второй кандидат набрал: " + secondCandidate * PERCENT / totalAmountOfCandidates + "%");
  }
}