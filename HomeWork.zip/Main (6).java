import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите длину прямоугольника:");
    int a = scanner.nextInt();
    System.out.println("Введите высоту прямоугольника:");
    int b = scannerSecond.nextInt();

    System.out.println("Периметр прямоугольника:");
    System.out.println(a * 2 + b * 2);
  }
}