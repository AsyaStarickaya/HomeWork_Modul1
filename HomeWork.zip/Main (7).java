import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите основание треугольника:");
    float a = scanner.nextFloat();
    System.out.println("Введите высоту треугольника:");
    float b = scannerSecond.nextFloat();

    System.out.println("Периметр треугольника:");
    System.out.println(a * b / 2);
  }
}