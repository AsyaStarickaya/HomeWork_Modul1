public class Main {
  public static void main(String[] args) {
    System.out.println("Старицкая Анастасия Владимировна");
    System.out.println("+79523995737");
    System.out.println("г. Санкт-Петербург, ул. Типанова. д. 20, кв.13");
  }
}