import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите количество пациентов в очереди:");
    int a = scanner.nextInt();

    System.out.println("Максимальное время ожидания:");
    System.out.println(a * Math.max(10, 20));

    System.out.println("Минимальное время ожидания:");
    System.out.println(a * Math.min(10, 20));

    System.out.println("Среднее время ожидания:");
    System.out.println(a * ((10+20)/2));
  }
}