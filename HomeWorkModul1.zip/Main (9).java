import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите число:");
    float a = scanner.nextFloat();

    System.out.println("Делим на 2:");
    System.out.println(a / 2);

    System.out.println("Делим на 5:");
    System.out.println(a / 5);

    System.out.println("Делим на 10:");
    System.out.println(a / 10);
  }
}