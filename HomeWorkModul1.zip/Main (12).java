import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите зарплату 1:");
    int a = scanner.nextInt();

    System.out.println("Введите зарплату 2:");
    int b = scanner.nextInt();

    System.out.println("Введите зарплату 3:");
    int c = scanner.nextInt();

    System.out.println("Введите зарплату 4:");
    int d = scanner.nextInt();

    int min1 = Math.min(a, b);
    int min2 = Math.min(c, d);
    int minFinal = Math.min(min1, min2);

    int max1 = Math.max(a, b);
    int max2 = Math.max(c, d);
    int maxFinal = Math.max(max1, max2);

    System.out.println("разница в зп:");
    System.out.println(maxFinal - minFinal);

  }
}