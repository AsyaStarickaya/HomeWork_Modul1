import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Введите количество проголосовавших за первого кандидата:");
    int x = scanner.nextInt();

    System.out.println("Введите количество проголосовавших за второго кандидата:");
    int y = scanner.nextInt();

    System.out.println("Первый кандидат набрал: " + x * 100 / (y+x) + "%");
    System.out.println("Второй кандидат набрал: " + y * 100 / (y+x) + "%");
  }
}