import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    Scanner scannerSecond = new Scanner(System.in);

    System.out.println("Введите переменную 1:");
    int a = scanner.nextInt();

    System.out.println("Введите переменную 2:");
    int b = scanner.nextInt();

    System.out.println("Введите переменную 3:");
    int c = scanner.nextInt();

    int d = Math.min(a, b);
    System.out.println("Минимальное значение из трёх введённых переменных:");
    System.out.println(Math.min(d, c));

  }
}